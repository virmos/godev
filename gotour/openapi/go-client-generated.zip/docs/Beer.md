# Beer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** |  | [optional] [default to null]
**BeerName** | **string** |  | [optional] [default to null]
**Style** | **string** |  | [optional] [default to null]
**Price** | **float32** |  | [optional] [default to null]
**QuantityOnHand** | **int32** |  | [optional] [default to null]
**Brewery** | [***Brewery**](Brewery.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

