# PagedResponsePageable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sort** | [***PagedResponsePageableSort**](PagedResponse_pageable_sort.md) |  | [optional] [default to null]
**Offset** | **int32** |  | [optional] [default to null]
**PageNumber** | **int32** |  | [optional] [default to null]
**PageSize** | **int32** |  | [optional] [default to null]
**Paged** | **bool** |  | [optional] [default to null]
**Unpaged** | **bool** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

