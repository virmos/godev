# {{classname}}

All URIs are relative to *https://dev.example.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteCustomerV1**](CustomersApi.md#DeleteCustomerV1) | **Delete** /v1/customers/{customerId} | Delete Customer By ID
[**GetCustomerByIdV1**](CustomersApi.md#GetCustomerByIdV1) | **Get** /v1/customers/{customerId} | Get Customer By ID
[**ListCustomersV1**](CustomersApi.md#ListCustomersV1) | **Get** /v1/customers | List Customers
[**V1CustomersCustomerIdPut**](CustomersApi.md#V1CustomersCustomerIdPut) | **Put** /v1/customers/{customerId} | Update Customer
[**V1CustomersPost**](CustomersApi.md#V1CustomersPost) | **Post** /v1/customers | New Customer

# **DeleteCustomerV1**
> DeleteCustomerV1(ctx, customerId)
Delete Customer By ID

Delete a customer by its Id value.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **customerId** | [**string**](.md)| Customer Id | 

### Return type

 (empty response body)

### Authorization

[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetCustomerByIdV1**
> Customer GetCustomerByIdV1(ctx, customerId)
Get Customer By ID

Get a single **Customer** by its Id value.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **customerId** | [**string**](.md)| Customer Id | 

### Return type

[**Customer**](Customer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ListCustomersV1**
> CustomerPagedList ListCustomersV1(ctx, optional)
List Customers

Get a list of customers in the system

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***CustomersApiListCustomersV1Opts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a CustomersApiListCustomersV1Opts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageNumber** | **optional.Int32**| Page Number | [default to 1]
 **pageSize** | **optional.Int32**| Page Size | [default to 25]

### Return type

[**CustomerPagedList**](CustomerPagedList.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **V1CustomersCustomerIdPut**
> V1CustomersCustomerIdPut(ctx, body, customerId)
Update Customer

Update customer by id.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Customer**](Customer.md)|  | 
  **customerId** | [**string**](.md)| Customer Id | 

### Return type

 (empty response body)

### Authorization

[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **V1CustomersPost**
> V1CustomersPost(ctx, body)
New Customer

Create a new customer

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Customer**](Customer.md)|  | 

### Return type

 (empty response body)

### Authorization

[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

