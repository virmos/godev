# CustomerPagedList

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Pageable** | [***PagedResponsePageable**](PagedResponse_pageable.md) |  | [optional] [default to null]
**TotalPages** | **int32** |  | [optional] [default to null]
**Last** | **bool** |  | [optional] [default to null]
**TotalElements** | **int32** |  | [optional] [default to null]
**Size** | **int32** |  | [optional] [default to null]
**Number** | **int32** |  | [optional] [default to null]
**NumberOfElements** | **int32** |  | [optional] [default to null]
**Sort** | [***PagedResponsePageableSort**](PagedResponse_pageable_sort.md) |  | [optional] [default to null]
**First** | **bool** |  | [optional] [default to null]
**Content** | [***[]Customer**](array.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

