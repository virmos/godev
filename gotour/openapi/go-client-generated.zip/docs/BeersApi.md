# {{classname}}

All URIs are relative to *https://dev.example.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**DeleteBeerV1**](BeersApi.md#DeleteBeerV1) | **Delete** /v1/beers/{beerId} | Delete Beer by Id
[**GetBeerByIdV1**](BeersApi.md#GetBeerByIdV1) | **Get** /v1/beers/{beerId} | Get Beer by ID
[**ListBeersV1**](BeersApi.md#ListBeersV1) | **Get** /v1/beers | List Beers
[**UpdateBeerByIdV1**](BeersApi.md#UpdateBeerByIdV1) | **Put** /v1/beers/{beerId} | Update Beer by ID
[**V1BeersPost**](BeersApi.md#V1BeersPost) | **Post** /v1/beers | New Beer

# **DeleteBeerV1**
> DeleteBeerV1(ctx, beerId)
Delete Beer by Id

Delete a beer resource by its ID value.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **beerId** | [**string**](.md)| Beer Id | 

### Return type

 (empty response body)

### Authorization

[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetBeerByIdV1**
> Beer GetBeerByIdV1(ctx, beerId)
Get Beer by ID

Get a single beer by its ID value.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **beerId** | [**string**](.md)| Beer Id | 

### Return type

[**Beer**](Beer.md)

### Authorization

[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ListBeersV1**
> BeerPagedList ListBeersV1(ctx, optional)
List Beers

List all beers in system.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***BeersApiListBeersV1Opts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a BeersApiListBeersV1Opts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **pageNumber** | **optional.Int32**| Page Number | [default to 1]
 **pageSize** | **optional.Int32**| Page Size | [default to 25]

### Return type

[**BeerPagedList**](BeerPagedList.md)

### Authorization

[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **UpdateBeerByIdV1**
> UpdateBeerByIdV1(ctx, body, beerId)
Update Beer by ID

Update a beer by its ID value.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Beer**](Beer.md)|  | 
  **beerId** | [**string**](.md)| Beer Id | 

### Return type

 (empty response body)

### Authorization

[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **V1BeersPost**
> V1BeersPost(ctx, body)
New Beer

Create a new Beer Object

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **body** | [**Beer**](Beer.md)|  | 

### Return type

 (empty response body)

### Authorization

[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

