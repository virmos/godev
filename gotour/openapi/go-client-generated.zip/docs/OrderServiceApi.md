# {{classname}}

All URIs are relative to *https://dev.example.com*

Method | HTTP request | Description
------------- | ------------- | -------------
[**V1CustomersCustomerIdOrdersPost**](OrderServiceApi.md#V1CustomersCustomerIdOrdersPost) | **Post** /v1/customers/{customerId}/orders | 

# **V1CustomersCustomerIdOrdersPost**
> V1CustomersCustomerIdOrdersPost(ctx, customerId, optional)


Place Order

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **customerId** | [**string**](.md)| Customer Id | 
 **optional** | ***OrderServiceApiV1CustomersCustomerIdOrdersPostOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a OrderServiceApiV1CustomersCustomerIdOrdersPostOpts struct
Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **body** | [**optional.Interface of BeerOrder**](BeerOrder.md)|  | 

### Return type

 (empty response body)

### Authorization

[JwtAuthToken](../README.md#JwtAuthToken)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

