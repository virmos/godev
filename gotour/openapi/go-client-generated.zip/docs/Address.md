# Address

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Line1** | **string** |  | [optional] [default to null]
**City** | **string** |  | [optional] [default to null]
**StateCode** | **string** | 2 Letter State Code | [optional] [default to null]
**ZipCode** | **string** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

